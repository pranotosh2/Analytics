create database abc_company;
use abc_company;
drop database if exists abc_company;
select * from user;
select * from deposit;
select * from withdrawal;
select count(*)from user;
select count(*) from deposit;
select count(*)from withdrawal;